# V3 Successor UKI - Owner Production Signing Runbook (Windows) - PACKAGE v3

This v3 package replaces the rejected v1 and v2 packages. If you received either, discard
them and use only v3. Changes in v3: no third-party executable anywhere in the ceremony
(OpenSSL is gone - the detached signature is proven by two independent implementations
already built into Windows); the signed UKI is verified mathematically instead of with
`signtool verify /pa` (which cannot work with a self-signed identity without a prohibited
trust-store change); and every script has a top-level guard so every failure, expected or
not, prints exactly one `STOP` line and exits nonzero.

You sign one file with a new production key on your own Windows computer. Everything is
zero cost. You never design, debug, or choose anything technical: every step tells you
exactly what to type, what you should see, when it passed, and when to stop.

- Time: about 30-45 minutes, mostly waiting for downloads.
- You need: your Windows 10/11 64-bit computer, internet, administrator rights, and TWO
  encrypted storage locations you control that are NOT the same physical device
  (for example: your internal drive with BitLocker/Device Encryption ON, plus one USB
  drive with BitLocker To Go ON). If you do not have two encrypted locations, STOP now
  and say so - Part 0 will check this for you and tell you.
- Nothing in this runbook asks you to pay for anything. If anything asks for payment,
  STOP and report it.

## FIRST ACTION

Press the Windows key, type `PowerShell`, right-click **Windows PowerShell**, choose
**Run as administrator**. Keep this window open for all parts. Everything below happens
in this one window.

## Setup (once): create the work folder and place the scripts

In the PowerShell window, copy-paste this line and press Enter:

```powershell
New-Item -ItemType Directory -Path C:\v3-signing\scripts -Force | Out-Null
```

Now save the five script files that came with this runbook into `C:\v3-signing\scripts`:

- V3-Part0-Preflight.ps1
- V3-Part1-KeyCreation.ps1
- V3-Part2-SignUKI.ps1
- V3-Part3-FinalizeAndDetachedSign.ps1
- V3-Part4-EvidenceAndCleanup.ps1

**One edit is required.** Open `C:\v3-signing\scripts\V3-Part0-Preflight.ps1` in Notepad.
At the top there are two clearly marked lines:

```powershell
$PrimaryPfxDir = 'E:\v3-secure-boot-primary'
$BackupPfxDir  = 'F:\v3-secure-boot-backup'
```

Replace `E:\v3-secure-boot-primary` with a folder on your FIRST encrypted location, and
`F:\v3-secure-boot-backup` with a folder on your SECOND encrypted location (different
physical device). Create both folders first (they can be empty). Save the file. This is
the only thing you will ever edit.

## SAFE vs PRIVATE - read once before starting

SAFE TO RETURN FOR REVIEW (public): everything that lands in `C:\v3-signing\REVIEW-EVIDENCE`.

NEVER SHARE / KEEP PRIVATE: the two `successor-secure-boot.pfx` files, the PFX password,
and the `C:\v3-signing\state` and `C:\v3-signing\work` folders. Never put any of these
in Git, GitHub, any repository, any CI system, email, chat, or cloud storage, and never
transfer them to any agent or assistant. They never leave your computer.

NEVER place the production certificate into the Trusted Root or Intermediate
Certification Authorities stores, on this or any other machine. The scripts never do,
and you must not either.

## How each part works

You run five parts in order, 0 then 1, 2, 3, 4. Each part prints either:

- `PART N PASS - ...` meaning everything worked; continue to the next part, or
- `STOP E_SOME_CODE - explanation` meaning STOP. Do not continue, do not retry with
  changes, do not look for workarounds. Report the exact code and message back.

Every script has a top-level guard: even a completely unexpected error is converted into
`STOP E_UNEXPECTED - <detail>` (detail is shortened and stripped of control characters;
it never contains the password or key material), the script exits with a failure code,
and no raw error text is ever shown. If a failure happens while a temporary key is in
the certificate store, cleanup is still attempted and verified; if cleanup also fails,
you see BOTH the original failure and a separate `STOP E_CLEANUP_FAILED` line.

There is no situation where you fix something yourself.

## Part 0 - automatic preflight (nothing secret)

```powershell
powershell -ExecutionPolicy Bypass -File C:\v3-signing\scripts\V3-Part0-Preflight.ps1
```

What it does: checks administrator mode and 64-bit Windows; checks your two folders are
on two different, encrypted physical drives; installs the zero-cost Windows SDK
10.0.26100 from Microsoft via winget (winget verifies the installer against its source
manifest hash; if winget is missing it prints exact manual instructions naming only the
official Microsoft SDK page); locates `signtool.exe`, verifies it carries a VALID
Authenticode signature whose signer is Microsoft Corporation, and records its path,
version and SHA-256; downloads the three public input files from the pinned public
repository address and verifies each byte count and full SHA-256:

- successor-unsigned.efi, 21164544 bytes, SHA-256 ed5d9d72be40592af3b14bd1fd9dc91a5976b14f350f9124ea414b975464d536
- successor-authority-record.v1.json, 46963 bytes, SHA-256 c09245ae3b60db34f050e29fd9f457a83fde95bd44efc70e9afda14fcbee0e88
- inventory.v1.json, 52390 bytes, SHA-256 a34edbf31bdacca8b2f836d496d01da5d57a8e8a1f46fcc7d63a9ab0dc297236

SignTool (a Microsoft-signed binary) is the ONLY executable this ceremony runs. There is
no OpenSSL and no other third-party tool: all verification is done by Windows itself and
by mathematical proofs inside the scripts.

Expected result: lines starting with VERIFIED, then `PART 0 PASS`.
PASS: you see `PART 0 PASS`. STOP: any `STOP E_...` line (for example E_ENCRYPTION_UNPROVEN
means one of the two drives is not encrypted; report it - do not buy anything).

## Part 1 - create the production signing identity

```powershell
powershell -ExecutionPolicy Bypass -File C:\v3-signing\scripts\V3-Part1-KeyCreation.ps1
```

It asks you to invent a NEW password and type it privately (you will not see the
characters). This password protects the two key files; it is never shown, logged, or
sent anywhere. You will need the same password in Parts 2 and 3 and again for later
signing phases, so write it down and keep the note with the key files.

It then creates the RSA-3072 SHA-256 code-signing identity named
`CN=V3 Successor UKI Secure Boot Authority`, proves the key is a genuine CNG key on the
Microsoft software provider (anything else = STOP E_KEY_PROVIDER), writes the encrypted
primary key file to your first encrypted location, an identical encrypted backup to your
second encrypted location, verifies the two files are byte-identical, exports the PUBLIC
certificate (which is safe), and removes the temporary copy from the certificate store
(with a verified-cleanup guarantee: if removal ever fails you get a precise
STOP E_CLEANUP_FAILED, never a hidden leftover).

Expected result: it prints a PUBLIC certificate thumbprint and a PUBLIC certificate
SHA-256, then `PART 1 PASS`.
PASS: `PART 1 PASS`. STOP: any `STOP E_...` line.

## Part 2 - sign the successor UKI

```powershell
powershell -ExecutionPolicy Bypass -File C:\v3-signing\scripts\V3-Part2-SignUKI.ps1
```

It re-verifies that the unsigned UKI on disk still exactly matches the certified SHA-256
ed5d9d72be40592af3b14bd1fd9dc91a5976b14f350f9124ea414b975464d536 (full value, checked
twice), asks for the PFX password privately, loads the key (and proves it is CNG,
non-exportable, RSA-3072), and signs with Microsoft SignTool (SHA-256 Authenticode, no
timestamp).

It then verifies the signature MATHEMATICALLY, with no trust store involved: it computes
the Windows PE Authenticode digest of the signed file (the current algorithm, fixed by
Microsoft security bulletin MS12-024: the whole file except the CheckSum field, the
Certificate Table directory entry, and the certificate table itself), decodes the
embedded PKCS#7 signature block, checks that the signed content's DigestInfo carries
exactly that digest and that the signer certificate is exactly your production
certificate, and finally checks the cryptographic signature itself with
SignedCms.CheckSignature(verifySignatureOnly) - the documented mode that verifies the
signature only, without any chain-of-trust evaluation.

`signtool verify /pa` is deliberately NOT used: it verifies chain-of-trust up to a
trusted root. A self-signed identity has no trusted root, so /pa would fail on a
perfectly good signature, and the only workaround would be adding the production
certificate to a persistent trust store - which is prohibited. The mathematical check
verifies exactly what was signed, byte for byte, and needs no trust anchor.

The temporary key is removed from the store inside an exception-safe guard: even if
something fails mid-part, removal is verified and a failure is a precise
STOP E_CLEANUP_FAILED that also prints the original problem.

Expected result: `Authenticode mathematical verification PASS ...`, then
`SIGNED UKI SHA-256: <64 hex characters>` then `PART 2 PASS`.
PASS: `PART 2 PASS`. STOP: any `STOP E_...` line.

## Part 3 - finalize the binding record and create the detached signature

```powershell
powershell -ExecutionPolicy Bypass -File C:\v3-signing\scripts\V3-Part3-FinalizeAndDetachedSign.ps1
```

It builds the final public binding record (the certified 200-record record plus the
Git commit/tree, the signed-UKI SHA-256 and the certificate SHA-256, in the frozen
canonical format, with a built-in round-trip proof that nothing else changed), then
creates the detached production signature required by the certified record rule:
RSA-PSS-SHA256 over SHA-256 of the bytes `V3-SUCCESSOR-UKI-EXTERNAL-BINDING:v1`,
one zero byte, then the finalized record.

It then verifies the signature by TWO independent implementations, both already built
into Windows - no third-party executable anywhere in this trust path:

1. Microsoft CNG: an immediate VerifyHash self-check, and
2. a full EMSA-PSS structural decode written into the script itself as pure public-key
   math (s^e mod n with the public key, MGF1-SHA256 unmasking, salt recovery): it PROVES
   the signature is really RSA-PSS with SHA-256, MGF1-SHA256, and a salt length of
   EXACTLY 32 bytes - anything else is STOP E_PSS_SALTLEN. Nothing is assumed.

The temporary key is removed under the same exception-safe verified-cleanup guard as
Part 2.

Expected result: `PSS STRUCTURAL PROOF PASS - ... salt length EXACTLY 32 bytes`, then
`PART 3 PASS`.
PASS: `PART 3 PASS`. STOP: any `STOP E_...` line.

## Part 4 - package evidence and clean up

```powershell
powershell -ExecutionPolicy Bypass -File C:\v3-signing\scripts\V3-Part4-EvidenceAndCleanup.ps1
```

It confirms the temporary key is gone from the certificate store, then assembles the
evidence folder against an EXACT list of 10 public files: the public certificate, the
unsigned and signed UKI, the original and finalized records, the detached signature,
the inventory, the SignTool signing transcript, the Authenticode verification
transcript, and the detached pre-image digest. Anything in the folder that is not on
that exact list is STOP E_UNEXPECTED_EVIDENCE; any key-file type (.pfx/.p12/.pvk/.key)
or password/secret/private file name is STOP E_SECRET_IN_EVIDENCE. It then writes
EVIDENCE-MANIFEST.json recording the SHA-256 and byte length of every OTHER evidence
file (a manifest never hashes itself) and re-checks the final folder contents.

Expected result: a clearly printed RETURN INSTRUCTIONS box, then `PART 4 PASS`.

## What you return

Return ONLY the folder `C:\v3-signing\REVIEW-EVIDENCE` (zip it if easier). All of it is
public evidence. Your returned evidence will be independently reviewed; any later
provisioning or other follow-on step remains under the separately applicable owner
approval and gates - this package neither grants nor waives any later authority.

Keep private, forever (never Git/GitHub/repository/CI/email/chat/cloud/agent transfer):
the two `successor-secure-boot.pfx` files (you will need them for future signing
phases), the PFX password, and the `state`/`work` folders.

## Complete STOP code table

The rule for EVERY code starting with E_ is always the same: stop and report the exact
code and message. This table explains the common ones; for any code not listed,
stop and report it exactly as printed.

| Code | Meaning | What you do |
|---|---|---|
| E_NOT_ADMIN | Window is not administrator | Close, reopen via Run as administrator, rerun |
| E_POWERSHELL / E_NOT_64BIT | Windows or PowerShell too old | STOP; report |
| E_STATE | A part was skipped or run out of order | Run the parts in order 0,1,2,3,4; if you did, STOP and report |
| E_PRIMARY_DIR / E_BACKUP_DIR | One of your two folders does not exist | Create it, fix the two edited lines, rerun Part 0 |
| E_ENCRYPTION_UNPROVEN | A key-storage drive is not encrypted | STOP; report. Do not buy anything |
| E_SAME_VOLUME / E_SAME_DISK | Both folders on one device | STOP; report |
| E_SDK_INSTALL / E_WINGET_MISSING / E_SIGNTOOL_* | SDK or SignTool problem | STOP; report the code |
| E_INPUT_SIZE / E_INPUT_HASH | A public download is wrong | STOP; report. Never fetch from another site |
| E_OUTPUT_EXISTS | An output already exists | STOP; report. Never overwrite |
| E_PFX_BACKUP_MISMATCH | The two key files differ | STOP; report. Delete nothing |
| E_KEY_PROVIDER / E_KEY_EXPORTABLE / E_KEY_SIZE / E_PRIVATE_KEY / E_KEYGEN | Key is not the exact required CNG/RSA-3072/non-exportable form | STOP; report |
| E_UNSIGNED_UKI_IDENTITY / E_STAGED_UKI_IDENTITY | Wrong unsigned UKI bytes | STOP; report |
| E_CERTIFICATE_* / E_*_MISMATCH | Certificate or file identity problem | STOP; report |
| E_SIGNTOOL_SIGN | Signing failed | STOP; report with signtool-sign.txt |
| E_AUTHENTICODE_PARSE / E_AUTHENTICODE_TABLE / E_AUTHENTICODE_PKCS7 | Signed-file structure problem | STOP; report |
| E_AUTHENTICODE_SIGNER / E_AUTHENTICODE_DIGEST / E_AUTHENTICODE_SIGNATURE | The mathematical Authenticode verification failed | STOP; report with authenticode-verify.txt |
| E_PSS_* / E_SIG_LENGTH / E_DETACHED_* / E_RECORD_FORMAT / E_FINAL_* | Detached signature or record problem | STOP; report |
| E_PSS_SALTLEN | Measured salt length is not exactly 32 bytes | STOP; report. Do not retry |
| E_CLEANUP_FAILED | Temporary key could not be removed from the store | STOP; report. Do not delete manually. The original failure, if any, is printed too |
| E_STORE_KEY_REMAINS | Store still holds the certificate at Part 4 | STOP; report. Do not delete manually |
| E_UNEXPECTED_EVIDENCE / E_SECRET_IN_EVIDENCE / E_EVIDENCE_SET / E_EVIDENCE_MISSING | Evidence folder contents are not exactly the expected public set | STOP; report. Remove nothing manually |
| E_UNEXPECTED | Any unexpected error (shown instead of raw error text) | STOP; report what you see |
| anything else unexpected | - | STOP; report what you see |
