# V3-Part4-EvidenceAndCleanup.ps1 (package v2) - elevated Windows PowerShell.
# Assembles the NON-SECRET review evidence folder against an EXACT allowlist (anything else = STOP),
# writes the manifest (hashes of every OTHER evidence file), verifies the final set, prints return instructions.
$ErrorActionPreference = 'Stop'
$Work = 'C:\v3-signing'
$Ev = "$Work\REVIEW-EVIDENCE"
function Stop-Step($code, $msg) { Write-Host "STOP $code - $msg"; exit 1 }
function Check($cond, $code, $msg) { if (-not $cond) { Stop-Step $code $msg } }

Write-Host '== V3 PART 4 EVIDENCE AND CLEANUP (v2) =='
Check (Test-Path -LiteralPath "$Work\state\state.json") 'E_STATE' 'Run Part 0 first.'
$state = Get-Content -LiteralPath "$Work\state\state.json" -Raw | ConvertFrom-Json
Check ($state.DetachedSigSha256) 'E_STATE' 'Run Part 3 first.'

# Store must not contain the production certificate anymore
Check (-not (Get-ChildItem 'Cert:\CurrentUser\My' | Where-Object Thumbprint -eq $state.CertThumbprint)) 'E_STORE_KEY_REMAINS' 'The production certificate is still in the certificate store. Report this code; do not delete it manually.'

# Exact public evidence allowlist: name -> source subfolder
$allowed = [ordered]@{
  'successor-secure-boot.cer'                    = 'public'
  'successor-unsigned.efi'                       = 'public'
  'successor-signed.efi'                         = 'public'
  'successor-authority-record.v1.json'           = 'public'
  'successor-authority-record-final.v1.json'     = 'public'
  'successor-authority-record-final.v1.sig'      = 'public'
  'inventory.v1.json'                            = 'public'
  'signtool-sign.txt'                            = 'work'
  'signtool-verify.txt'                          = 'work'
  'openssl-verify.txt'                           = 'work'
  'detached-preimage.sha256'                     = 'work'
}
$prohibitedExt = @('.pfx', '.p12', '.pvk', '.key')

# Pre-scan: the evidence folder must contain nothing unexpected before assembly
if (Test-Path -LiteralPath $Ev) {
  Get-ChildItem -LiteralPath $Ev -Recurse -File | ForEach-Object {
    Check (($allowed.Contains($_.Name)) -or ($_.Name -eq 'EVIDENCE-MANIFEST.json')) 'E_UNEXPECTED_EVIDENCE' "Unexpected file in the evidence folder: $($_.Name). Remove nothing manually; report this code."
    Check ($prohibitedExt -notcontains $_.Extension.ToLower()) 'E_SECRET_IN_EVIDENCE' "Prohibited file type in the evidence folder: $($_.Name). Remove nothing manually; report this code."
    Check ($_.Name -notmatch 'password|secret|private') 'E_SECRET_IN_EVIDENCE' "Suspicious filename in the evidence folder: $($_.Name). Remove nothing manually; report this code."
  }
} else {
  New-Item -ItemType Directory -Path $Ev | Out-Null
}

# Copy EXACTLY the allowlist (every entry mandatory - no copy-if-present)
foreach ($name in $allowed.Keys) {
  $src = Join-Path (Join-Path $Work $allowed[$name]) $name
  Check (Test-Path -LiteralPath $src) 'E_EVIDENCE_MISSING' "$src is missing; report this code."
  Copy-Item -LiteralPath $src -Destination $Ev -Force
}

# Verify the assembled set is exactly the allowlist
$now = Get-ChildItem -LiteralPath $Ev -Recurse -File | Where-Object Name -ne 'EVIDENCE-MANIFEST.json'
$names = @($now | ForEach-Object Name | Sort-Object)
$want = @($allowed.Keys | Sort-Object)
Check (($names.Count -eq $want.Count) -and (-not (Compare-Object $names $want))) 'E_EVIDENCE_SET' 'The assembled evidence set does not exactly equal the expected public set. Remove nothing manually; report this code.'

# Manifest: SHA-256 of every OTHER evidence file (a manifest never hashes itself)
$manifest = [ordered]@{}
$manifest.schema = 'v3.production-signing-evidence.v2'
$manifest.note = 'This manifest records the SHA-256 and byte length of every OTHER evidence file. It does not hash itself.'
$manifest.createdUtc = (Get-Date).ToUniversalTime().ToString('o')
$manifest.gitCommit = '92741cbdefaa78adc33bc3c74935a45f9558b88c'
$manifest.gitTree = '9cc2e40fab25c2231d5a6cefa285d2e3e65a7bee'
$manifest.domain = 'V3-SUCCESSOR-UKI-EXTERNAL-BINDING:v1'
$manifest.signtoolPath = $state.SignToolPath
$manifest.signtoolVersion = $state.SignToolVersion
$manifest.signtoolSha256 = $state.SignToolSha256
$manifest.openSslPath = $state.OpenSslPath
$manifest.openSslVersion = $state.OpenSslVersion
$manifest.openSslSha256 = $state.OpenSslSha256
$manifest.openSslAuthenticode = $state.OpenSslAuthenticode
$manifest.certificateThumbprint = $state.CertThumbprint
$manifest.certificateDerSha256 = $state.CertDerSha256
$manifest.unsignedUkiSha256 = 'ed5d9d72be40592af3b14bd1fd9dc91a5976b14f350f9124ea414b975464d536'
$manifest.signedUkiSha256 = $state.SignedUkiSha256
$manifest.finalRecordSha256 = $state.FinalRecordSha256
$manifest.detachedSignatureSha256 = $state.DetachedSigSha256
$manifest.pssSaltLengthBytes = 32
$manifest.openSslCrossCheck = $state.OpenSslCrossCheck
$manifest.twoEncryptedPfxCopiesIdentical = $true
$files = [ordered]@{}
foreach ($name in $allowed.Keys) {
  $fi = Get-Item -LiteralPath (Join-Path $Ev $name)
  $files[$name] = (@{ bytes = $fi.Length; sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $fi.FullName).Hash.ToLower() })
}
$manifest.files = $files
($manifest | ConvertTo-Json -Depth 5) | Set-Content -LiteralPath "$Ev\EVIDENCE-MANIFEST.json" -Encoding ASCII

# Final sweep: allowlist + manifest only, no prohibited material
Get-ChildItem -LiteralPath $Ev -Recurse -File | ForEach-Object {
  Check (($allowed.Contains($_.Name)) -or ($_.Name -eq 'EVIDENCE-MANIFEST.json')) 'E_UNEXPECTED_EVIDENCE' "Unexpected file in the final evidence folder: $($_.Name). Remove nothing manually; report this code."
  Check ($prohibitedExt -notcontains $_.Extension.ToLower()) 'E_SECRET_IN_EVIDENCE' "Prohibited file type in the final evidence folder: $($_.Name). Remove nothing manually; report this code."
}

[GC]::Collect()
Write-Host ''
Write-Host '================ RETURN INSTRUCTIONS ================'
Write-Host "SAFE TO RETURN FOR REVIEW: the entire folder $Ev (everything in it is public evidence)."
Write-Host 'NEVER SHARE / KEEP PRIVATE - never put these in Git, GitHub, any repository, any CI system,'
Write-Host 'email, chat, or cloud storage, and never transfer them to any agent or assistant:'
Write-Host '  - the two successor-secure-boot.pfx files on your two encrypted drives (keep them safe; later phases need them)'
Write-Host '  - the PFX password'
Write-Host '  - the C:\v3-signing\state and C:\v3-signing\work folders'
Write-Host '====================================================='
Write-Host 'PART 4 PASS - evidence ready. Return ONLY the REVIEW-EVIDENCE folder.'
