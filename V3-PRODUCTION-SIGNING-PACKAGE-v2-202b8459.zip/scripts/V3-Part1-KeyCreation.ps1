# V3-Part1-KeyCreation.ps1 (package v2) - elevated Windows PowerShell. Creates the production signing identity
# per the certified design, asserts the CNG (RSACng) provider, and removes the temporary store copy.
# The PFX password is entered interactively and is NEVER printed, logged, or stored.
$ErrorActionPreference = 'Stop'
$Work = 'C:\v3-signing'
function Stop-Step($code, $msg) { Write-Host "STOP $code - $msg"; exit 1 }
function Check($cond, $code, $msg) { if (-not $cond) { Stop-Step $code $msg } }

Write-Host '== V3 PART 1 KEY CREATION (v2) =='
Check (Test-Path -LiteralPath "$Work\state\state.json") 'E_STATE' 'Run Part 0 first.'
$state = Get-Content -LiteralPath "$Work\state\state.json" -Raw | ConvertFrom-Json
$primary = Join-Path $state.PrimaryPfxDir 'successor-secure-boot.pfx'
$backup  = Join-Path $state.BackupPfxDir  'successor-secure-boot.pfx'
$public  = "$Work\public\successor-secure-boot.cer"
Check (-not (Test-Path -LiteralPath $primary)) 'E_OUTPUT_EXISTS' "$primary already exists. Do not overwrite a retained key; report this code."
Check (-not (Test-Path -LiteralPath $backup)) 'E_OUTPUT_EXISTS' "$backup already exists. Do not overwrite a retained key; report this code."
Check (-not (Test-Path -LiteralPath $public)) 'E_OUTPUT_EXISTS' "$public already exists; report this code."

Write-Host 'You will now be asked to invent and type a NEW password for the two encrypted key files.'
Write-Host 'It is typed privately (not shown), never stored by these scripts, and never sent anywhere.'
Write-Host 'You must be able to reproduce it to sign later phases - write it down and keep it with the two key files.'

$cert = $null
$origErr = $null
try {
  $password = Read-Host 'New PFX password' -AsSecureString
  $subject = 'CN=V3 Successor UKI Secure Boot Authority'
  $notBefore = (Get-Date).ToUniversalTime().Date
  $notAfter = $notBefore.AddYears(10).AddSeconds(-1)
  $cert = New-SelfSignedCertificate `
    -Type Custom -Subject $subject `
    -KeyAlgorithm RSA -KeyLength 3072 -HashAlgorithm SHA256 `
    -KeyExportPolicy Exportable -KeyUsage DigitalSignature `
    -TextExtension @('2.5.29.19={critical}{text}ca=false','2.5.29.37={text}1.3.6.1.5.5.7.3.3') `
    -CertStoreLocation 'Cert:\CurrentUser\My' -NotBefore $notBefore -NotAfter $notAfter
  Check ($null -ne $cert) 'E_KEYGEN' 'Certificate creation failed.'

  # Exact mechanism assertion: the persisted private key must be CNG (RSACng) on the Microsoft software provider
  $k = [Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($cert)
  Check ($null -ne $k) 'E_KEYGEN' 'No private key on the new certificate; report this code.'
  Check ($k -is [System.Security.Cryptography.RSACng]) 'E_KEY_PROVIDER' 'The new private key is not a CNG key (RSACng). Report this code; do not continue with another provider.'
  Check ($k.Key.Provider.Provider -eq 'Microsoft Software Key Storage Provider') 'E_KEY_PROVIDER' "Unexpected key provider '$($k.Key.Provider.Provider)'. Report this code."
  Check ($k.KeySize -eq 3072) 'E_KEY_SIZE' "Key size is $($k.KeySize), expected 3072. Report this code."

  Export-PfxCertificate -Cert $cert.PSPath -FilePath $primary -Password $password -CryptoAlgorithmOption AES256_SHA256 -NoProperties
  Copy-Item -LiteralPath $primary -Destination $backup -Force
  Export-Certificate -Cert $cert.PSPath -FilePath $public -Type CERT

  $hP = (Get-FileHash -Algorithm SHA256 -LiteralPath $primary).Hash
  $hB = (Get-FileHash -Algorithm SHA256 -LiteralPath $backup).Hash
  Check ($hP -eq $hB) 'E_PFX_BACKUP_MISMATCH' 'The two encrypted key files differ. Delete neither; report this code.'

  $cerSha = (Get-FileHash -Algorithm SHA256 -LiteralPath $public).Hash.ToLower()
  $thumb = $cert.Thumbprint
} catch {
  $origErr = $_
  throw
} finally {
  $password = $null
  if ($cert -ne $null) {
    try { Remove-Item -LiteralPath $cert.PSPath -Force -ErrorAction Stop } catch {}
    if (Test-Path -LiteralPath $cert.PSPath) {
      Write-Host 'STOP E_CLEANUP_FAILED - could not remove the temporary certificate from the certificate store. Do not delete it manually; report this code.'
      if ($origErr) { Write-Host "Original failure before cleanup: $($origErr.Exception.Message)" }
      exit 1
    }
  }
  [GC]::Collect()
}

$state | Add-Member -NotePropertyName CertThumbprint -NotePropertyValue $thumb -Force
$state | Add-Member -NotePropertyName CertDerSha256 -NotePropertyValue $cerSha -Force
$state | ConvertTo-Json | Set-Content -LiteralPath "$Work\state\state.json" -Encoding ASCII

Write-Host ''
Write-Host "PUBLIC certificate thumbprint: $thumb"
Write-Host "PUBLIC certificate file SHA-256: $cerSha"
Write-Host 'PART 1 PASS - production identity created (CNG provider verified); two identical encrypted key files exist on two separate encrypted drives; no key remains in the certificate store.'
Write-Host 'Continue to Part 2.'
