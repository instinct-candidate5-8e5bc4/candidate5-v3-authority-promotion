# V3-Part2-SignUKI.ps1 (package v2) - elevated Windows PowerShell. Signs the exact certified unsigned UKI.
# Imported-key lifetime is exception-safe (try/finally with verified removal).
$ErrorActionPreference = 'Stop'
$Work = 'C:\v3-signing'
$ExpectedUnsigned = 'ed5d9d72be40592af3b14bd1fd9dc91a5976b14f350f9124ea414b975464d536'
function Stop-Step($code, $msg) { Write-Host "STOP $code - $msg"; exit 1 }
function Check($cond, $code, $msg) { if (-not $cond) { Stop-Step $code $msg } }

Write-Host '== V3 PART 2 SIGN THE SUCCESSOR UKI (v2) =='
Check (Test-Path -LiteralPath "$Work\state\state.json") 'E_STATE' 'Run Part 0 first.'
$state = Get-Content -LiteralPath "$Work\state\state.json" -Raw | ConvertFrom-Json
Check ($state.CertThumbprint) 'E_STATE' 'Run Part 1 first.'

$signtool = $state.SignToolPath
Check (Test-Path -LiteralPath $signtool) 'E_SIGNTOOL_MISSING' 'signtool.exe missing; rerun Part 0.'
$stNow = (Get-FileHash -Algorithm SHA256 -LiteralPath $signtool).Hash.ToLower()
Check ($stNow -eq $state.SignToolSha256) 'E_SIGNTOOL_IDENTITY' 'signtool.exe changed since Part 0. Report this code.'

$unsigned = "$Work\public\successor-unsigned.efi"
$staged   = "$Work\work\successor.efi"
$signed   = "$Work\public\successor-signed.efi"
Check (-not (Test-Path -LiteralPath $signed)) 'E_OUTPUT_EXISTS' "$signed already exists; report this code."
Check ((Get-FileHash -Algorithm SHA256 -LiteralPath $unsigned).Hash.ToLower() -eq $ExpectedUnsigned) 'E_UNSIGNED_UKI_IDENTITY' 'The unsigned UKI on disk does not match the certified SHA-256 ed5d9d72be40592af3b14bd1fd9dc91a5976b14f350f9124ea414b975464d536. Report this code.'
if (Test-Path -LiteralPath $staged) { Remove-Item -LiteralPath $staged -Force }
Copy-Item -LiteralPath $unsigned -Destination $staged
Check ((Get-FileHash -Algorithm SHA256 -LiteralPath $staged).Hash.ToLower() -eq $ExpectedUnsigned) 'E_STAGED_UKI_IDENTITY' 'Staging copy mismatch; report this code.'

$thumbprint = $state.CertThumbprint
Check (-not (Get-ChildItem 'Cert:\CurrentUser\My' | Where-Object Thumbprint -eq $thumbprint)) 'E_CERTIFICATE_ALREADY_PRESENT' 'The production certificate is already in the store. Report this code; do not delete it manually.'

$imported = $null
$origErr = $null
try {
  $password = Read-Host 'PFX password' -AsSecureString
  $primary = Join-Path $state.PrimaryPfxDir 'successor-secure-boot.pfx'
  $imported = Import-PfxCertificate -FilePath $primary -CertStoreLocation 'Cert:\CurrentUser\My' -Password $password -Exportable:$false
  $password = $null
  Check ($imported.Thumbprint -eq $thumbprint) 'E_CERTIFICATE_IDENTITY' 'Imported certificate does not match the Part 1 thumbprint. Report this code.'

  # Exact mechanism assertion: CNG (RSACng), non-exportable, RSA-3072
  $rsa = [Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($imported)
  Check ($null -ne $rsa) 'E_PRIVATE_KEY' 'Could not access the private key; report this code.'
  Check ($rsa -is [System.Security.Cryptography.RSACng]) 'E_KEY_PROVIDER' 'The imported private key is not CNG (RSACng). Report this code.'
  Check ($rsa.Key.ExportPolicy -eq [Security.Cryptography.CngExportPolicies]::None) 'E_KEY_EXPORTABLE' 'The imported key is exportable; the design requires a non-exportable temporary import. Report this code.'
  Check ($rsa.KeySize -eq 3072) 'E_KEY_SIZE' "Key size is $($rsa.KeySize), expected 3072. Report this code."

  & $signtool sign /fd SHA256 /s My /sha1 $thumbprint $staged | Out-String | Set-Content -LiteralPath "$Work\work\signtool-sign.txt" -Encoding ASCII
  Check ($LASTEXITCODE -eq 0) 'E_SIGNTOOL_SIGN' "SignTool sign failed (exit $LASTEXITCODE). Report this code with $Work\work\signtool-sign.txt."
  & $signtool verify /pa /all /v $staged | Out-String | Set-Content -LiteralPath "$Work\work\signtool-verify.txt" -Encoding ASCII
  Check ($LASTEXITCODE -eq 0) 'E_SIGNTOOL_VERIFY' "SignTool verify failed (exit $LASTEXITCODE). Report this code with $Work\work\signtool-verify.txt."

  Move-Item -LiteralPath $staged -Destination $signed
  $signedSha = (Get-FileHash -Algorithm SHA256 -LiteralPath $signed).Hash.ToLower()
  $state | Add-Member -NotePropertyName SignedUkiSha256 -NotePropertyValue $signedSha -Force
  $state | ConvertTo-Json | Set-Content -LiteralPath "$Work\state\state.json" -Encoding ASCII
} catch {
  $origErr = $_
  throw
} finally {
  $password = $null
  if ($imported -ne $null) {
    try { Remove-Item -LiteralPath $imported.PSPath -Force -ErrorAction Stop } catch {}
    if (Test-Path -LiteralPath $imported.PSPath) {
      Write-Host 'STOP E_CLEANUP_FAILED - could not remove the temporary imported key from the certificate store. Do not delete it manually; report this code.'
      if ($origErr) { Write-Host "Original failure before cleanup: $($origErr.Exception.Message)" }
      exit 1
    }
  }
  $imported = $null
  [GC]::Collect()
}

Write-Host ''
Write-Host "SIGNED UKI SHA-256: $signedSha"
Write-Host 'PART 2 PASS - successor UKI signed and verified; temporary key removed from the store. Continue to Part 3.'
