# V3-Part4-EvidenceAndCleanup.ps1 - elevated Windows PowerShell.
# Assembles the NON-SECRET review evidence folder, verifies the store is clean, prints return instructions.
$ErrorActionPreference = 'Stop'
$Work = 'C:\v3-signing'
$Ev = "$Work\REVIEW-EVIDENCE"
function Stop-Step($code, $msg) { Write-Host "STOP $code - $msg"; exit 1 }
function Check($cond, $code, $msg) { if (-not $cond) { Stop-Step $code $msg } }

Write-Host '== V3 PART 4 EVIDENCE AND CLEANUP =='
Check (Test-Path -LiteralPath "$Work\state\state.json") 'E_STATE' 'Run Part 0 first.'
$state = Get-Content -LiteralPath "$Work\state\state.json" -Raw | ConvertFrom-Json
Check ($state.DetachedSigSha256) 'E_STATE' 'Run Part 3 first.'

# Store must not contain the production certificate anymore
Check (-not (Get-ChildItem 'Cert:\CurrentUser\My' | Where-Object Thumbprint -eq $state.CertThumbprint)) 'E_STORE_KEY_REMAINS' 'The production certificate is still in the certificate store. Report this code; do not delete it manually.'

# Copy non-secret evidence
$items = @(
  'successor-secure-boot.cer',
  'successor-unsigned.efi',
  'successor-signed.efi',
  'successor-authority-record.v1.json',
  'successor-authority-record-final.v1.json',
  'successor-authority-record-final.v1.sig',
  'inventory.v1.json'
)
foreach ($f in $items) {
  $src = "$Work\public\$f"
  Check (Test-Path -LiteralPath $src) 'E_EVIDENCE_MISSING' "$src missing; report this code."
  Copy-Item -LiteralPath $src -Destination $Ev -Force
}
foreach ($f in @('signtool-sign.txt','signtool-verify.txt','openssl-verify.txt','detached-preimage.sha256')) {
  $src = "$Work\work\$f"
  if (Test-Path -LiteralPath $src) { Copy-Item -LiteralPath $src -Destination $Ev -Force }
}

# Manifest of every evidence file + key public facts
$manifest = [ordered]@{}
$manifest.schema = 'v3.production-signing-evidence.v1'
$manifest.createdUtc = (Get-Date).ToUniversalTime().ToString('o')
$manifest.gitCommit = '92741cbdefaa78adc33bc3c74935a45f9558b88c'
$manifest.gitTree = '9cc2e40fab25c2231d5a6cefa285d2e3e65a7bee'
$manifest.domain = 'V3-SUCCESSOR-UKI-EXTERNAL-BINDING:v1'
$manifest.signtoolPath = $state.SignToolPath
$manifest.signtoolVersion = $state.SignToolVersion
$manifest.signtoolSha256 = $state.SignToolSha256
$manifest.certificateThumbprint = $state.CertThumbprint
$manifest.certificateDerSha256 = $state.CertDerSha256
$manifest.unsignedUkiSha256 = 'ed5d9d72be40592af3b14bd1fd9dc91a5976b14f350f9124ea414b975464d536'
$manifest.signedUkiSha256 = $state.SignedUkiSha256
$manifest.finalRecordSha256 = $state.FinalRecordSha256
$manifest.detachedSignatureSha256 = $state.DetachedSigSha256
$manifest.pssSaltLengthBytes = $state.PssSaltLength
$manifest.openSslCrossCheck = $state.OpenSslCrossCheck
$manifest.twoEncryptedPfxCopiesIdentical = $true
$files = @{}
Get-ChildItem -LiteralPath $Ev -File | ForEach-Object { $files[$_.Name] = (@{ bytes = $_.Length; sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName).Hash.ToLower() }) }
$manifest.files = $files
($manifest | ConvertTo-Json -Depth 5) | Set-Content -LiteralPath "$Ev\EVIDENCE-MANIFEST.json" -Encoding ASCII

# Safety: prove no private material is inside the evidence folder
Get-ChildItem -LiteralPath $Ev -Recurse -File | ForEach-Object {
  Check ($_.Extension -ne '.pfx') 'E_SECRET_IN_EVIDENCE' "A PFX file was found in the evidence folder: $($_.Name). Remove nothing manually; report this code."
}

[GC]::Collect()
Write-Host ''
Write-Host '================ RETURN INSTRUCTIONS ================'
Write-Host "SAFE TO RETURN FOR REVIEW: the entire folder $Ev (everything in it is public evidence)."
Write-Host 'NEVER SHARE / KEEP PRIVATE:'
Write-Host '  - the two successor-secure-boot.pfx files on your two encrypted drives (keep them safe; later phases need them)'
Write-Host '  - the PFX password'
Write-Host '  - the C:\v3-signing\state and C:\v3-signing\work folders'
Write-Host '====================================================='
Write-Host 'PART 4 PASS - evidence ready. Return ONLY the REVIEW-EVIDENCE folder.'
