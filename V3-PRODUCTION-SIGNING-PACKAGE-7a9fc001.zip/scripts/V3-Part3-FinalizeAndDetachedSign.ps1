# V3-Part3-FinalizeAndDetachedSign.ps1 - elevated Windows PowerShell.
# Finalizes the canonical external binding record (frozen format), produces the detached
# RSA-PSS-SHA256 production signature over UTF8(domain) || 0x00 || finalized record,
# self-verifies, then PROVES the signature's actual PSS parameters by full EMSA-PSS
# structural decoding (no parameter is assumed; the measured salt length is reported).
$ErrorActionPreference = 'Stop'
$Work = 'C:\v3-signing'
$Domain = 'V3-SUCCESSOR-UKI-EXTERNAL-BINDING:v1'
$GitCommit = '92741cbdefaa78adc33bc3c74935a45f9558b88c'
$GitTree   = '9cc2e40fab25c2231d5a6cefa285d2e3e65a7bee'
function Stop-Step($code, $msg) { Write-Host "STOP $code - $msg"; exit 1 }
function Check($cond, $code, $msg) { if (-not $cond) { Stop-Step $code $msg } }

Write-Host '== V3 PART 3 FINALIZE BINDING RECORD AND DETACHED SIGNATURE =='
Check (Test-Path -LiteralPath "$Work\state\state.json") 'E_STATE' 'Run Part 0 first.'
$state = Get-Content -LiteralPath "$Work\state\state.json" -Raw | ConvertFrom-Json
Check ($state.SignedUkiSha256 -and $state.CertDerSha256) 'E_STATE' 'Run Parts 1 and 2 first.'

# Recompute both public hashes from disk (never trust state alone)
$signed = "$Work\public\successor-signed.efi"
$cerFile = "$Work\public\successor-secure-boot.cer"
$signedSha = (Get-FileHash -Algorithm SHA256 -LiteralPath $signed).Hash.ToLower()
$cerSha = (Get-FileHash -Algorithm SHA256 -LiteralPath $cerFile).Hash.ToLower()
Check ($signedSha -eq $state.SignedUkiSha256) 'E_SIGNED_MISMATCH' 'Signed UKI changed since Part 2; report this code.'
Check ($cerSha -eq $state.CertDerSha256) 'E_CERT_MISMATCH' 'Certificate file changed since Part 1; report this code.'

# 1. Finalize the canonical record (frozen deterministic surgery; verified by round-trip)
$srcPath = "$Work\public\successor-authority-record.v1.json"
$finPath = "$Work\public\successor-authority-record-final.v1.json"
Check (-not (Test-Path -LiteralPath $finPath)) 'E_OUTPUT_EXISTS' "$finPath already exists; report this code."
$raw = [IO.File]::ReadAllBytes($srcPath)
Check (($raw.Length -ge 2) -and ($raw[$raw.Length-2] -eq 0x7d) -and ($raw[$raw.Length-1] -eq 0x0a)) 'E_RECORD_FORMAT' 'Canonical record does not end with }+LF as required.'
$body = [Text.Encoding]::UTF8.GetString($raw, 0, $raw.Length - 2)
Check ($body.StartsWith('{"certification":')) 'E_RECORD_FORMAT' 'Canonical record does not start with the expected first key.'
$out = '{"certificateDerSha256":"' + $cerSha + '",' + $body.Substring(1)
$m1 = '"records":'
Check (($out.IndexOf($m1) -ge 0) -and ($out.IndexOf($m1, $out.IndexOf($m1) + 1) -lt 0)) 'E_RECORD_FORMAT' 'records marker not unique.'
$out = $out.Replace($m1, '"gitCommit":"' + $GitCommit + '","gitTree":"' + $GitTree + '","records":')
$m2 = '"signingRule":'
Check (($out.IndexOf($m2) -ge 0) -and ($out.IndexOf($m2, $out.IndexOf($m2) + 1) -lt 0)) 'E_RECORD_FORMAT' 'signingRule marker not unique.'
$out = $out.Replace($m2, '"signedUkiSha256":"' + $signedSha + '","signingRule":')
$finalStr = $out + '}' + "`n"
# structural checks: JSON parses; round-trip removal reproduces the original bytes exactly
try { $null = ($finalStr | ConvertFrom-Json) } catch { Stop-Step 'E_FINAL_JSON' 'Finalized record is not valid JSON; report this code.' }
$back = $finalStr.Replace('"certificateDerSha256":"' + $cerSha + '",', '')
$back = $back.Replace('"gitCommit":"' + $GitCommit + '","gitTree":"' + $GitTree + '",', '')
$back = $back.Replace('"signedUkiSha256":"' + $signedSha + '",', '')
$backBytes = [Text.Encoding]::UTF8.GetBytes($back)
Check ($backBytes.Length -eq $raw.Length) 'E_FINAL_ROUNDTRIP' 'Round-trip length mismatch; report this code.'
for ($i = 0; $i -lt $raw.Length; $i++) { if ($backBytes[$i] -ne $raw[$i]) { Stop-Step 'E_FINAL_ROUNDTRIP' "Round-trip byte mismatch at $i; report this code." } }
$finBytes = [Text.Encoding]::UTF8.GetBytes($finalStr)
[IO.File]::WriteAllBytes($finPath, $finBytes)
$finSha = (Get-FileHash -Algorithm SHA256 -LiteralPath $finPath).Hash.ToLower()
Write-Host "Finalized binding record: $finPath"
Write-Host "Finalized record SHA-256: $finSha"

# 2. Detached RSA-PSS-SHA256 signature over UTF8(domain) || 0x00 || finalized record
$thumbprint = $state.CertThumbprint
Check (-not (Get-ChildItem 'Cert:\CurrentUser\My' | Where-Object Thumbprint -eq $thumbprint)) 'E_CERTIFICATE_ALREADY_PRESENT' 'Production certificate already in store; report this code.'
$password = Read-Host 'PFX password' -AsSecureString
$primary = Join-Path $state.PrimaryPfxDir 'successor-secure-boot.pfx'
$imported = Import-PfxCertificate -FilePath $primary -CertStoreLocation 'Cert:\CurrentUser\My' -Password $password -Exportable:$false
$password = $null
Check ($imported.Thumbprint -eq $thumbprint) 'E_CERTIFICATE_IDENTITY' 'Imported certificate mismatch; report this code.'

$domainBytes = [Text.Encoding]::UTF8.GetBytes($Domain)
$preimage = New-Object byte[] ($domainBytes.Length + 1 + $finBytes.Length)
[Array]::Copy($domainBytes, 0, $preimage, 0, $domainBytes.Length)
$preimage[$domainBytes.Length] = 0
[Array]::Copy($finBytes, 0, $preimage, $domainBytes.Length + 1, $finBytes.Length)
$sha = [Security.Cryptography.SHA256]::Create()
$digest = $sha.ComputeHash($preimage)
[IO.File]::WriteAllBytes("$Work\work\detached-preimage.sha256", $digest)

$rsa = [Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($imported)
Check ($null -ne $rsa) 'E_PRIVATE_KEY' 'Could not access the private key; report this code.'
$sig = $rsa.SignHash($digest, [Security.Cryptography.HashAlgorithmName]::SHA256, [Security.Cryptography.RSASignaturePadding]::Pss)
Check ($sig.Length -eq 384) 'E_SIG_LENGTH' "Signature is $($sig.Length) bytes, expected 384 for RSA-3072; report this code."
$selfOk = $rsa.VerifyHash($digest, $sig, [Security.Cryptography.HashAlgorithmName]::SHA256, [Security.Cryptography.RSASignaturePadding]::Pss)
Check ($selfOk) 'E_DETACHED_VERIFY' 'Immediate VerifyHash self-check failed; report this code.'
$sigPath = "$Work\public\successor-authority-record-final.v1.sig"
[IO.File]::WriteAllBytes($sigPath, $sig)

# 3. Structural proof of the ACTUAL PSS parameters (full EMSA-PSS decode; nothing assumed)
Add-Type -AssemblyName System.Numerics | Out-Null
function ToBI([byte[]]$be) { $le = [byte[]]$be.Clone(); [Array]::Reverse($le); $le += ([byte]0); [System.Numerics.BigInteger]::new([byte[]]$le) }
function ToBE([System.Numerics.BigInteger]$x, [int]$len) {
  $b = $x.ToByteArray()
  if (($b.Length -eq ($len + 1)) -and ($b[$len] -eq 0)) { $t = New-Object byte[] $len; [Array]::Copy($b, $t, $len); $b = $t }
  if ($b.Length -gt $len) { throw 'E_PSS_INTERNAL' }
  $p = New-Object byte[] $len; [Array]::Copy($b, 0, $p, 0, $b.Length); [Array]::Reverse($p); return [byte[]]$p
}
function MGF1([byte[]]$seed, [int]$len) {
  $sha2 = [Security.Cryptography.SHA256]::Create()
  $ms = New-Object System.IO.MemoryStream
  $c = [uint32]0
  while ($ms.Length -lt $len) { $ctr = [BitConverter]::GetBytes($c); [Array]::Reverse($ctr); $ms.Write($sha2.ComputeHash(($seed + $ctr)), 0, 32); $c++ }
  $bytes = $ms.ToArray(); $r = New-Object byte[] $len; [Array]::Copy($bytes, $r, $len); return [byte[]]$r
}
$pub = [Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPublicKey($imported)
$params = $pub.ExportParameters($false)
$n = ToBI $params.Modulus
$e = ToBI $params.Exponent
$s = ToBI $sig
$modBits = $params.Modulus.Length * 8
$emBits = $modBits - 1
$emLen = [math]::Ceiling($emBits / 8)
Check ($emLen -eq $sig.Length) 'E_PSS_LENGTH' 'Encoded-message length mismatch; report this code.'
$EM = ToBE ([System.Numerics.BigInteger]::ModPow($s, $e, $n)) $emLen
$hLen = 32
$dbLen = $emLen - $hLen - 1
Check ($EM[$emLen - 1] -eq 0xbc) 'E_PSS_TRAILER' 'EMSA-PSS trailer byte missing; report this code.'
$H = $EM[$dbLen..($emLen - 2)]
$maskedDB = $EM[0..($dbLen - 1)]
$mask = MGF1 $H $dbLen
$DB = New-Object byte[] $dbLen
for ($i = 0; $i -lt $dbLen; $i++) { $DB[$i] = $maskedDB[$i] -bxor $mask[$i] }
$DB[0] = $DB[0] -band (0xFF -shr (8 * $emLen - $emBits))
$i = 0; while (($i -lt $dbLen) -and ($DB[$i] -eq 0)) { $i++ }
Check (($i -lt $dbLen) -and ($DB[$i] -eq 1)) 'E_PSS_SEPARATOR' 'EMSA-PSS 0x01 separator missing; report this code.'
$saltLen = $dbLen - $i - 1
Check ($saltLen -ge 1) 'E_PSS_SALTLEN' "Recovered salt length is $saltLen; report this code."
$salt = $DB[($i + 1)..($dbLen - 1)]
$mp = New-Object byte[] (8 + 32 + $saltLen)
[Array]::Copy($digest, 0, $mp, 8, 32)
[Array]::Copy($salt, 0, $mp, 40, $saltLen)
$Hp = ([Security.Cryptography.SHA256]::Create()).ComputeHash($mp)
$psLen = $emLen - $saltLen - $hLen - 2
$DBp = New-Object byte[] $dbLen
$DBp[$psLen] = 1
[Array]::Copy($salt, 0, $DBp, $psLen + 1, $saltLen)
$mask2 = MGF1 $Hp $dbLen
for ($j = 0; $j -lt $dbLen; $j++) { $DBp[$j] = $DBp[$j] -bxor $mask2[$j] }
$DBp[0] = $DBp[0] -band (0xFF -shr (8 * $emLen - $emBits))
$EMp = New-Object byte[] $emLen
[Array]::Copy($DBp, 0, $EMp, 0, $dbLen)
[Array]::Copy($Hp, 0, $EMp, $dbLen, 32)
$EMp[$emLen - 1] = 0xbc
$proofOk = $true
for ($k = 0; $k -lt $emLen; $k++) { if ($EMp[$k] -ne $EM[$k]) { $proofOk = $false } }
Check ($proofOk) 'E_PSS_PROOF' 'Structural EMSA-PSS proof failed; report this code.'
Write-Host "PSS PROOF PASS - signature is valid RSA-PSS-SHA256; measured salt length: $saltLen bytes (proven, not assumed)"

# 4. Optional OpenSSL cross-check with auto salt recovery (skipped deterministically if openssl absent)
$ossl = Get-Command openssl.exe -ErrorAction SilentlyContinue
if ($ossl) {
  $pem = "-----BEGIN CERTIFICATE-----`n" + [Convert]::ToBase64String($imported.Export('Cert'), 'InsertLineBreaks') + "`n-----END CERTIFICATE-----`n"
  Set-Content -LiteralPath "$Work\work\public-cert.pem" -Value $pem -Encoding ASCII
  & openssl.exe pkeyutl -verify -certin -inkey "$Work\work\public-cert.pem" -keyform PEM -in "$Work\work\detached-preimage.sha256" -sigfile $sigPath -pkeyopt rsa_padding_mode:pss -pkeyopt rsa_pss_saltlen:-2 -pkeyopt digest:sha256 | Out-String | Set-Content -LiteralPath "$Work\work\openssl-verify.txt" -Encoding ASCII
  Check ($LASTEXITCODE -eq 0) 'E_OPENSSL_CROSSCHECK' "OpenSSL cross-check failed (exit $LASTEXITCODE); report this code with $Work\work\openssl-verify.txt."
  Write-Host 'OpenSSL cross-check PASS (salt length auto-recovered, not assumed)'
  $osslResult = 'PASS'
} else {
  Write-Host 'OpenSSL not installed: cross-check SKIPPED (deterministic; the structural proof above is complete on its own)'
  $osslResult = 'SKIPPED_NOT_INSTALLED'
}

Remove-Item -LiteralPath $imported.PSPath
Check (-not (Test-Path -LiteralPath $imported.PSPath)) 'E_STORE_KEY_REMAINS' 'Store cleanup failed; report this code.'
$imported = $null; $rsa = $null; $pub = $null
[GC]::Collect()

$state | Add-Member -NotePropertyName FinalRecordSha256 -NotePropertyValue $finSha -Force
$state | Add-Member -NotePropertyName DetachedSigSha256 -NotePropertyValue ((Get-FileHash -Algorithm SHA256 -LiteralPath $sigPath).Hash.ToLower()) -Force
$state | Add-Member -NotePropertyName PssSaltLength -NotePropertyValue $saltLen -Force
$state | Add-Member -NotePropertyName OpenSslCrossCheck -NotePropertyValue $osslResult -Force
$state | ConvertTo-Json | Set-Content -LiteralPath "$Work\state\state.json" -Encoding ASCII

Write-Host ''
Write-Host "Detached signature SHA-256: $($state.DetachedSigSha256)"
Write-Host 'PART 3 PASS - binding record finalized and signed; PSS parameters proven. Continue to Part 4.'
